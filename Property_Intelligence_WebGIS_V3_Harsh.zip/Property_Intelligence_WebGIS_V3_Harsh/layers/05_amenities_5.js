var json_05_amenities_5 = {
"type": "FeatureCollection",
"name": "05_amenities_5",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{"type":"Feature","properties":{"Name":"Community Park","Category":"Park"},"geometry":{"type":"Point","coordinates":[74.30161,31.5036125]}},
{"type":"Feature","properties":{"Name":"Central School","Category":"School"},"geometry":{"type":"Point","coordinates":[74.30345,31.5036125]}},
{"type":"Feature","properties":{"Name":"Health Clinic","Category":"Healthcare"},"geometry":{"type":"Point","coordinates":[74.30529,31.5036125]}},
{"type":"Feature","properties":{"Name":"Retail Center","Category":"Shopping"},"geometry":{"type":"Point","coordinates":[74.3070725,31.50187]}}
]
}
