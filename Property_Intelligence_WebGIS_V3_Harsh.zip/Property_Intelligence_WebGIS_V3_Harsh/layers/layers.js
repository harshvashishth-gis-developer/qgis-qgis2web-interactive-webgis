var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            'type':'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_01_parcels_1 = new ol.format.GeoJSON();
var features_01_parcels_1 = format_01_parcels_1.readFeatures(json_01_parcels_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_01_parcels_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_01_parcels_1.addFeatures(features_01_parcels_1);
var lyr_01_parcels_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_01_parcels_1, 
                style: style_01_parcels_1,
                popuplayertitle: '01_parcels',
                interactive: true,
    title: '01_parcels<br />\
    <img src="styles/legend/01_parcels_1_0.png" /> Available<br />\
    <img src="styles/legend/01_parcels_1_1.png" /> Reserved<br />\
    <img src="styles/legend/01_parcels_1_2.png" /> Sold<br />' });
var format_02_development_boundary_2 = new ol.format.GeoJSON();
var features_02_development_boundary_2 = format_02_development_boundary_2.readFeatures(json_02_development_boundary_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_02_development_boundary_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_02_development_boundary_2.addFeatures(features_02_development_boundary_2);
var lyr_02_development_boundary_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_02_development_boundary_2, 
                style: style_02_development_boundary_2,
                popuplayertitle: '02_development_boundary',
                interactive: true,
                title: '<img src="styles/legend/02_development_boundary_2.png" /> 02_development_boundary'
            });
var format_04_buildings_3 = new ol.format.GeoJSON();
var features_04_buildings_3 = format_04_buildings_3.readFeatures(json_04_buildings_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_04_buildings_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_04_buildings_3.addFeatures(features_04_buildings_3);
var lyr_04_buildings_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_04_buildings_3, 
                style: style_04_buildings_3,
                popuplayertitle: '04_buildings',
                interactive: false,
                title: '<img src="styles/legend/04_buildings_3.png" /> 04_buildings'
            });
var format_03_roads_4 = new ol.format.GeoJSON();
var features_03_roads_4 = format_03_roads_4.readFeatures(json_03_roads_4, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_03_roads_4 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_03_roads_4.addFeatures(features_03_roads_4);
var lyr_03_roads_4 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_03_roads_4, 
                style: style_03_roads_4,
                popuplayertitle: '03_roads',
                interactive: false,
                title: '<img src="styles/legend/03_roads_4.png" /> 03_roads'
            });
var format_05_amenities_5 = new ol.format.GeoJSON();
var features_05_amenities_5 = format_05_amenities_5.readFeatures(json_05_amenities_5, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_05_amenities_5 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_05_amenities_5.addFeatures(features_05_amenities_5);
var lyr_05_amenities_5 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_05_amenities_5, 
                style: style_05_amenities_5,
                popuplayertitle: '05_amenities',
                interactive: false,
                title: '<img src="styles/legend/05_amenities_5.png" /> 05_amenities'
            });

lyr_OpenStreetMap_0.setVisible(true);lyr_01_parcels_1.setVisible(true);lyr_02_development_boundary_2.setVisible(true);lyr_04_buildings_3.setVisible(true);lyr_03_roads_4.setVisible(true);lyr_05_amenities_5.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_01_parcels_1,lyr_02_development_boundary_2,lyr_04_buildings_3,lyr_03_roads_4,lyr_05_amenities_5];
lyr_01_parcels_1.set('fieldAliases', {'Parcel_ID': 'Parcel ID', 'Area_m2': 'Area (m²)', 'Land_Use': 'Land Use', 'Status': 'Availability Status', 'Price_USD': 'Price (USD)', 'Owner_Type': 'Ownership Type', 'Development_Type': 'Development Type', });
lyr_02_development_boundary_2.set('fieldAliases', {'Project': 'Project', });
lyr_04_buildings_3.set('fieldAliases', {'Building_ID': 'Building_ID', 'Type': 'Type', 'Floors': 'Floors', });
lyr_03_roads_4.set('fieldAliases', {'Road_Name': 'Road_Name', 'Road_Type': 'Road_Type', });
lyr_05_amenities_5.set('fieldAliases', {'Name': 'Name', 'Category': 'Category', });
lyr_01_parcels_1.set('fieldImages', {'Parcel_ID': 'TextEdit', 'Area_m2': 'Range', 'Land_Use': 'TextEdit', 'Status': 'TextEdit', 'Price_USD': 'Range', 'Owner_Type': 'TextEdit', 'Development_Type': 'TextEdit', });
lyr_02_development_boundary_2.set('fieldImages', {'Project': 'TextEdit', });
lyr_04_buildings_3.set('fieldImages', {'Building_ID': 'TextEdit', 'Type': 'TextEdit', 'Floors': 'Range', });
lyr_03_roads_4.set('fieldImages', {'Road_Name': 'TextEdit', 'Road_Type': 'TextEdit', });
lyr_05_amenities_5.set('fieldImages', {'Name': 'TextEdit', 'Category': 'TextEdit', });
lyr_01_parcels_1.set('fieldLabels', {'Parcel_ID': 'no label', 'Area_m2': 'no label', 'Land_Use': 'no label', 'Status': 'no label', 'Price_USD': 'no label', 'Owner_Type': 'no label', 'Development_Type': 'no label', });
lyr_02_development_boundary_2.set('fieldLabels', {'Project': 'no label', });
lyr_04_buildings_3.set('fieldLabels', {'Building_ID': 'no label', 'Type': 'no label', 'Floors': 'no label', });
lyr_03_roads_4.set('fieldLabels', {'Road_Name': 'no label', 'Road_Type': 'no label', });
lyr_05_amenities_5.set('fieldLabels', {'Name': 'no label', 'Category': 'no label', });
lyr_05_amenities_5.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});