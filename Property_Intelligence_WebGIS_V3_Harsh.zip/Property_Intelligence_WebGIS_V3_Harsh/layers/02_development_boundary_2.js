var json_02_development_boundary_2 = {
"type": "FeatureCollection",
"name": "02_development_boundary_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{"type":"Feature","properties":{"Project":"Greenfield Property Development"},"geometry":{"type":"Polygon","coordinates":[[[74.29975,31.49975],[74.3069,31.49975],[74.3069,31.5034],[74.29975,31.5034],[74.29975,31.49975]]]}}
]
}
